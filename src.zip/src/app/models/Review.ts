import mongoose, { Schema, model, models } from "mongoose";

// Interface para o documento de reviews (mesma estrutura que Imovel)
export interface IReview {
  AnoConstrucao: string;
  AreaPrivativa: string;
  AreaTotal: string;
  Bairro: string;
  BairroComercial: string;
  Banheiro7: string;
  Banheiro8: string;
  BanheiroSocialQtd: string;
  Banheiros1: string;
  Banheiros2: string;
  Banheiros3: string;
  Banheiros4: string;
  Banheiros5: string;
  Banheiros6: string;
  Bloco: string;
  CEP: string;
  Categoria: string;
  CategoriaDois: string;
  CategoriaTres: string;
  Cidade: string;
  Codigo: string;
  Complemento: string;
  Condominio: string;
  Construtora: string;
  DataEntrega: string;
  DataHoraAtualizacao: string;
  DescricaoDiferenciais: string;
  DescricaoUnidades: string;
  DestaquesDiferenciais: string;
  DestaquesLazer: string;
  DestaquesLocalizacao: string;
  Dormitorio2: string;
  Dormitorio3: string;
  Dormitorio4: string;
  Dormitorio5: string;
  Dormitorio6: string;
  Dormitorio7: string;
  Dormitorio8: string;
  Dormitorios: string;
  DormitoriosAntigo: string;
  Empreendimento: string;
  Endereco: string;
  FaixaPreco1: string;
  FaixaPreco2: string;
  FaixaPreco3: string;
  FaixaPreco4: string;
  FaixaPreco5: string;
  FaixaPreco6: string;
  FaixaPreco7: string;
  FaixaPreco8: string;
  FichaTecnica: string;
  FinalidadeStatus: Record<string, boolean>;
  Foto: Record<
    string,
    {
      Codigo: string;
      FotoPequena: string;
      Foto: string;
      Destaque: string;
      Tipo: string;
      Descricao: string;
    }
  >;
  FotoEmpreendimento: string[];
  Latitude: string;
  Longitude: string;
  Metragem1: string;
  Metragem2: string;
  Metragem3: string;
  Metragem4: string;
  Metragem5: string;
  Metragem6: string;
  Metragem7: string;
  Metragem8: string;
  MetragemAnt: string;
  MetragemAnt2: string;
  MetragemAnt3: string;
  MetragemAnt4: string;
  MetragemAnt5: string;
  MetragemAnt6: string;
  MetragemAnt7: string;
  MetragemAnt8: string;
  Numero: string;
  Situacao: string;
  Status: string;
  SuiteAntigo: string;
  Suites: string;
  Suites2: string;
  Suites3: string;
  Suites4: string;
  Suites5: string;
  Suites6: string;
  Suites7: string;
  Suites8: string;
  TipoEndereco: string;
  TituloSite: string;
  Tour360: string;
  UF: string;
  Vagas: string;
  Vagas1: string;
  Vagas2: string;
  Vagas3: string;
  Vagas4: string;
  Vagas5: string;
  Vagas6: string;
  Vagas7: string;
  Vagas8: string;
  VagasAntigo: string;
  ValorAluguel2: string;
  ValorAluguel3: string;
  ValorAluguel5: string;
  ValorAluguel6: string;
  ValorAluguel7: string;
  ValorAluguel8: string;
  ValorAluguelSite: string;
  ValorAluguel_4: string;
  ValorAntigo: string;
  ValorCobertura: string;
  ValorCobertura2: string;
  ValorCondominio: string;
  ValorDiaria: string;
  ValorGarden: string;
  ValorGarden2: string;
  ValorIptu: string;
  ValorLocacao: string;
  ValorVenda: string;
  ValorVenda2: string;
  ValorVenda3: string;
  ValorVenda4: string;
  Video: Record<
    string,
    {
      Codigo: string;
      VideoCodigo: string;
      Video: string;
      Destaque: string;
      Tipo: string;
    }
  >;
  Titulo?: string;
  Valor?: string;
}

// Schema do Review (igual ao Imovel)
const ReviewSchema: Schema = new Schema(
  {
    AnoConstrucao: String,
    AreaPrivativa: String,
    AreaTotal: String,
    Bairro: String,
    BairroComercial: String,
    Banheiro7: String,
    Banheiro8: String,
    BanheiroSocialQtd: String,
    Banheiros1: String,
    Banheiros2: String,
    Banheiros3: String,
    Banheiros4: String,
    Banheiros5: String,
    Banheiros6: String,
    Bloco: String,
    CEP: String,
    Categoria: String,
    CategoriaDois: String,
    CategoriaTres: String,
    Cidade: String,
    Codigo: { type: String, index: true },
    Complemento: String,
    Construtora: String,
    DataEntrega: String,
    DataHoraAtualizacao: String,
    DescricaoDiferenciais: String,
    DescricaoUnidades: String,
    DestaquesDiferenciais: String,
    DestaquesLazer: String,
    DestaquesLocalizacao: String,
    Dormitorio2: String,
    Dormitorio3: String,
    Dormitorio4: String,
    Dormitorio5: String,
    Dormitorio6: String,
    Dormitorio7: String,
    Dormitorio8: String,
    Dormitorios: String,
    DormitoriosAntigo: String,
    Empreendimento: String,
    Endereco: String,
    FaixaPreco1: String,
    FaixaPreco2: String,
    FaixaPreco3: String,
    FaixaPreco4: String,
    FaixaPreco5: String,
    FaixaPreco6: String,
    FaixaPreco7: String,
    FaixaPreco8: String,
    FichaTecnica: String,
    FinalidadeStatus: Object,
    Foto: Object,
    FotoEmpreendimento: [String],
    Latitude: String,
    Longitude: String,
    Metragem1: String,
    Metragem2: String,
    Metragem3: String,
    Metragem4: String,
    Metragem5: String,
    Metragem6: String,
    Metragem7: String,
    Metragem8: String,
    MetragemAnt: String,
    MetragemAnt2: String,
    MetragemAnt3: String,
    MetragemAnt4: String,
    MetragemAnt5: String,
    MetragemAnt6: String,
    MetragemAnt7: String,
    MetragemAnt8: String,
    Numero: String,
    Situacao: String,
    Status: String,
    SuiteAntigo: String,
    Suites: String,
    Suites2: String,
    Suites3: String,
    Suites4: String,
    Suites5: String,
    Suites6: String,
    Suites7: String,
    Suites8: String,
    TipoEndereco: String,
    TituloSite: String,
    Tour360: String,
    UF: String,
    Vagas: String,
    Vagas1: String,
    Vagas2: String,
    Vagas3: String,
    Vagas4: String,
    Vagas5: String,
    Vagas6: String,
    Vagas7: String,
    Vagas8: String,
    VagasAntigo: String,
    ValorAluguel2: String,
    ValorAluguel3: String,
    ValorAluguel5: String,
    ValorAluguel6: String,
    ValorAluguel7: String,
    ValorAluguel8: String,
    ValorAluguelSite: String,
    ValorAluguel_4: String,
    ValorAntigo: String,
    ValorCobertura: String,
    ValorCobertura2: String,
    ValorCondominio: String,
    ValorDiaria: String,
    ValorGarden: String,
    ValorGarden2: String,
    ValorIptu: String,
    ValorLocacao: String,
    ValorVenda: String,
    ValorVenda2: String,
    ValorVenda3: String,
    ValorVenda4: String,
    Video: Object,
    Titulo: String,
    Valor: String
  },
  {
    timestamps: true,
    collection: 'reviews', // Usando a collection 'reviews' para dados de automação
    strict: false,
  }
);

// Verificando se o modelo já existe para evitar redefinição
const Review = models.Review || model("Review", ReviewSchema);

export default Review; 