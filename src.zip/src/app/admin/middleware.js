export { default } from "next/middleware";

export const config = {
  matcher: "/admin/:path*",
};
